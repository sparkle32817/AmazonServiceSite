create definer = root@localhost view tbl_view_service_used_times as
select `s`.`id` AS `id`, `s`.`name` AS `name`, `t`.`request_time` AS `request_time`, `t`.`client_id` AS `client_id`
from (`service`.`tbl_service` `s`
         left join `service`.`tbl_task` `t` on ((`t`.`service_id` = `s`.`id`)))
order by `s`.`id`;

