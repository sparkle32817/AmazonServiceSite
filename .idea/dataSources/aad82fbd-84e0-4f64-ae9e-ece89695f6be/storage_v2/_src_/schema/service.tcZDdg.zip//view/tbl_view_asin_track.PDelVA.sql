create definer = root@localhost view tbl_view_asin_track as
select `d`.`id`                  AS `id`,
       `d`.`asin_id`             AS `asin_id`,
       `d`.`keyword`             AS `keyword`,
       `d`.`exact_search_volume` AS `exact_search_volume`,
       `d`.`broad_search_volume` AS `broad_search_volume`,
       `d`.`competing_product`   AS `competing_product`,
       `d`.`rank`                AS `rank`,
       `d`.`date_last_updated`   AS `date_last_updated`,
       `d`.`is_last`             AS `is_last`,
       `d`.`exist_status`        AS `exist_status`,
       `a`.`client_id`           AS `client_id`,
       `a`.`asin_num`            AS `asin_num`,
       `m`.`country_code`        AS `country_code`,
       `m`.`name`                AS `market_url`
from ((`service`.`tbl_service_tracking_asin` `a` join `service`.`tbl_service_tracking_detail` `d` on ((`a`.`id` = `d`.`asin_id`)))
         join `service`.`tbl_market` `m` on ((`a`.`market_id` = `m`.`id`)));

