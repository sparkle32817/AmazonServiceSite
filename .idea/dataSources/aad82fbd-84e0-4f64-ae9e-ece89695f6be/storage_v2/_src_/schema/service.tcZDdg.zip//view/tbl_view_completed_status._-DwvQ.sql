create definer = root@localhost view tbl_view_completed_status as
select `i`.`id`                                                                                   AS `id`,
       `i`.`name`                                                                                 AS `name`,
       `i`.`password`                                                                             AS `password`,
       `i`.`current_working_status`                                                               AS `current_working_status`,
       `i`.`enable_status`                                                                        AS `enable_status`,
       `i`.`service_permission`                                                                   AS `service_permission`,
       `i`.`permission`                                                                           AS `permission`,
       `i`.`logout_time`                                                                          AS `logout_time`,
       `i`.`last_ip`                                                                              AS `last_ip`,
       `i`.`last_country`                                                                         AS `last_country`,
       `t`.`start_time`                                                                           AS `start_time`,
       `t`.`end_time`                                                                             AS `end_time`,
       sec_to_time(avg(time_to_sec((select timediff(`t`.`end_time`, `t`.`start_time`) limit 1)))) AS `complete_time`,
       count((select timediff(`t`.`end_time`, `t`.`start_time`) limit 1))                         AS `complete_count`
from (`service`.`tbl_employee_info` `i`
         left join `service`.`tbl_task` `t` on ((`t`.`employee_id` = `i`.`id`)))
where (`i`.`permission` = 0)
group by `i`.`id`
order by `i`.`id`;

