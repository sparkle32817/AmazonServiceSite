create definer = root@localhost view tbl_view_all_task as
select `t`.`id`                                                    AS `id`,
       `t`.`client_id`                                             AS `client_id`,
       `t`.`service_id`                                            AS `service_id`,
       `t`.`status`                                                AS `status`,
       `t`.`request_time`                                          AS `request_time`,
       `t`.`employee_id`                                           AS `employee_id`,
       `t`.`start_time`                                            AS `start_time`,
       `t`.`end_time`                                              AS `end_time`,
       `t`.`related_task_id`                                       AS `related_task_id`,
       `t`.`market_id`                                             AS `market_id`,
       `t`.`is_visited`                                            AS `is_visited`,
       `t`.`is_approved_task`                                      AS `is_approved_task`,
       (select timediff(`t`.`end_time`, `t`.`start_time`) limit 1) AS `completion_time`,
       `c`.`user_name`                                             AS `client_name`,
       `s`.`name`                                                  AS `service`,
       `e`.`name`                                                  AS `employee_name`,
       `m`.`name`                                                  AS `market_place`
from ((((`service`.`tbl_task` `t` join `service`.`tbl_client` `c` on ((`c`.`id` = `t`.`client_id`))) join `service`.`tbl_service` `s` on ((`s`.`id` = `t`.`service_id`))) join `service`.`tbl_market` `m` on ((`m`.`id` = `t`.`market_id`)))
         left join `service`.`tbl_employee_info` `e` on ((`e`.`id` = `t`.`employee_id`)));

